# แผนเกษียณ — Retirement Planner

> Interactive retirement planning dashboard  
> คำนวณแบบ year-by-year · บันทึกอัตโนมัติ · Export PDF

## 🚀 Deploy ขึ้น GitHub Pages (ฟรี)

### ขั้นตอน (ทำครั้งเดียว ~5 นาที)

**1. สร้าง GitHub repo**
```
https://github.com/new
```
- ตั้งชื่อ: `retirement-planner` (หรืออะไรก็ได้)
- ตั้งเป็น **Public**
- กด **Create repository**

**2. Upload ไฟล์**

วิธีง่ายที่สุด — ลาก `index.html` ไปวางใน repo:
```
กด "uploading an existing file" → ลาก index.html → Commit changes
```

หรือใช้ Git:
```bash
git init
git add index.html
git commit -m "Initial deploy"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/retirement-planner.git
git push -u origin main
```

**3. เปิด GitHub Pages**
```
Settings → Pages → Source: Deploy from a branch
Branch: main / (root) → Save
```

**4. เข้าใช้งาน**
```
https://YOUR_USERNAME.github.io/retirement-planner/
```

ใช้เวลา ~1-2 นาทีหลัง deploy ครั้งแรก

---

## ✨ Features

| Feature | รายละเอียด |
|---------|-----------|
| **Year-by-year simulation** | คำนวณทีละปี ไม่ใช่แค่ compound ตรงๆ |
| **Auto-save** | บันทึกค่าลง localStorage อัตโนมัติ กลับมาครั้งหน้าค่าเดิม |
| **Export PDF** | พิมพ์ report สรุปพร้อมตาราง parameters |
| **Reset** | ล้างค่ากลับ default ได้ตลอด |

## 📊 หมวดที่คำนวณ

1. **🏛️ PVD** — กองทุนสำรองเลี้ยงชีพ (พนักงาน + นายจ้างสมทบ + เงินเดือนขึ้น)
2. **🏦 หุ้นสหกรณ์** — พร้อม cap logic → overflow → S&P 500
3. **📈 หุ้นปันผลไทย** — ทบต้นรวมปันผล
4. **💰 เงินฝากสหกรณ์** — ออมรายเดือน + ดอกเบี้ย
5. **🏢 คอนโดให้เช่า** — หลังหักค่าใช้จ่าย + vacancy
6. **📋 หนี้แม่** — ตัดต้น + ดอกเบี้ย ติดตามวันหมด
7. **🛡️ Unit Linked** — จ่ายเบี้ยจำกัดปี ทบต้นต่อ
8. **₿ คริปโต** — BTC/ETH/BNB/SOL wildcard (แสดงแยก ไม่นับในเป้าหลัก)

## 🔒 Privacy

ข้อมูลทั้งหมดอยู่ใน **localStorage ในเครื่องของคุณเท่านั้น**  
ไม่มีการส่งข้อมูลไปที่ server ใดๆ

---

*ตัวเลขเป็นการประมาณการเท่านั้น ไม่ใช่คำแนะนำทางการเงิน*
